--[[
Created by vJoeyz#5115 (Ome Joey)
Installed on 2Fast Racing Servers
Please do not redistribute
]]--

local M = {}

return M